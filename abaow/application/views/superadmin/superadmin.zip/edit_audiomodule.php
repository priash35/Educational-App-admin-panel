<?php include 'master/header.php'; ?>

	<div class="page-content">
		<div class="container-fluid">	
			<section class="card">
				<div class="card-block">
					

					<div class="row m-t-lg">
						<div class="col-md-6">
						<div class="tbl-cell">
							<h3>Edit Module</h3>
							
						</div>
						
							<form name="myform" id="myform" action="<?php echo base_url()?>admin/update_audiomodule" method="post" enctype="multipart/form-data">
								<div class="form-group">
									<div class="form-control-wrapper">
									<?php foreach ($records1 as $row){?>
										<!--<label class="form-label">Enter New Page Name : </label>-->
										<input type="hidden" class="form-control"  name="module_id" value="<?php echo $row->id;?>">
										<input type="text" class="form-control"  name="course_id" value="<?php echo $row->course_id;?>">
										
										<label class="form-label" for="signup_v1-username">Module Name:</label>
										<div class="form-control-wrapper">
											<input type="text" class="form-control" name="module_name" value="<?php echo $row->module_name;?>" required>
										</div><br>
										
										<label class="form-label" for="signup_v1-username">Audio:</label>
												<div class="form-control-wrapper">
												 
													<input type="hidden" class="form-control" name="module_audio" value="<?php echo $row->module_audio;?>">
													
													<input type="file" class="form-control" name="module_audio">
													
													<audio controls>
													 <source src="<?php echo $row->module_audio;?>" type="audio/mpeg">
													</audio>
													<?php $audio= $row->module_audio;
															//echo $audio; 
															$link= explode("/", $audio);
															$link_value= end($link);?>
													<label class="form-label" for="signup_v1-username"><?php echo $link_value;?></label>
												</div><br>	
										
																			
									
									<label class="form-label" for="signup_v1-username">Module Description:</label>
									<div class="form-control-wrapper">
										<textarea style="width:90%;"  type="text" id ="module_desc" name="module_desc" ><?php echo $row->module_desc;?></textarea>
									</div><br>	
										
									<label class="form-label" for="signup_v1-username">Duration:</label>
											<div class="form-control-wrapper">
												<input type="text" class="form-control" name="module_dur" value="<?php echo $row->duration;?>" required>
											</div><br>
									
									<label class="form-label" for="signup_v1-username">Module After:</label>
												<div class="form-control-wrapper">
											<!--<input type="text" class="form-control" name="module_dur" value="<?php echo $row->module_after;?>" required>-->
													<select name="module_after" id="module_after" class="form-control" style="width:70%"	>
													
												
													<?php
													$res=$row->course_id;
													$r_id=$row->id;
													$sql="select module_name,id , module_after from course_curriculum where course_id=$res";
													$query= $this->db->query($sql);
													$mod=$query->result();
													//print_r($res);
													
														  foreach ($mod as $value) 
														{
														//	echo $value->id;
														//	echo $value->module_after;
															$selected=$value->module_after;
															$sql1="select id,module_name from course_curriculum where course_id=$selected";
															$query1= $this->db->query($sql1);
															$res1=$query1->result();
															foreach($res1 as $row1)
															{
																echo "<option value='".$row1->id."' >".$row1->module_name."</option>";
															}
															
															
															
															echo "<option value='".$value->id."' >".$value->module_name."</option>";
														}  
													?>
													</select>
												</div><br>		

										<!--<select name="module_after" id="module_after" class="form-control" style="width:70%"	>
											<option value="<?php //echo $row->id;?>"><?php //echo $row->module_after;?></option>
										</select>	-->									
																		
										<?php }   ?> 
									</div>
									
								</div>
								<div class="form-group">
									<button type="submit" name="update_audiomodule" class="btn">Update Module</button>
								</div>
							</form>
						</div>
						
					
				</div>
			</section>
		</div><!--.container-fluid-->
	</div><!--.page-content-->
	


	
	
	<?php include 'master/footer.php'; ?>
	<!--.footer anre -content-->
	
	<script type="text/javascript">
		 $(document).ready(function(){
			$('#btnhello').click(function(){
				var fullname = $('#fullname').val();
				if(fullname ==''){
					//alert('#bn-success');
					$('#bn-danger').html('This field is required');

				}
				else{
					$.ajax({
					type:'POST',
					data:{fullname: fullname},
					url:'<?php echo site_url('page/hello');?>',
					success: function(result){
						$('#bn-success').html(result);
					}
				});
				}
				
			});
		}); 
		
		
		$(document).on('click','.status_checks',function()
		 { 
		var status = ($(this).hasClass("btn-success")) ? '0' : '1'; 
		var msg = (status=='0')? 'Deactivate' : 'Activate'; 
		if(confirm("Are you sure to "+ msg))
		{ 
			var current_element = $(this); 
			var id = $(current_element).attr('data');
			url = "<?php echo base_url().'page/update_status'?>"; 
				$.ajax({
				  type:"POST",
				  url: url, 
				  data: {"id":id,"status":status}, 
				  success: function(data) { 
				  location.reload();
			} });
		 }  
		 });
		
	</script>
	<script>
		$(function() {
			/* ==========================================================================
			 Validation
			 ========================================================================== */

			$('#btnhello').validate({
				submit: {
					settings: {
						inputContainer: '.form-group'
					}
				}
			});

			$('#form-signin_v2').validate({
				submit: {
					settings: {
						inputContainer: '.form-group',
						errorListClass: 'form-error-text-block',
						display: 'block',
						insertion: 'prepend'
					}
				}
			});

			$('#btnhello').validate({
				submit: {
					settings: {
						inputContainer: '.form-group',
						errorListClass: 'form-tooltip-error'
					}
				}
			});

			$('#form-signup_v2').validate({
				submit: {
					settings: {
						inputContainer: '.form-group',
						errorListClass: 'form-tooltip-error'
					}
				}
			});
		});
	</script>

<script src="<?php echo base_url()?>assets/js/app.js"></script>
</body>
</html>